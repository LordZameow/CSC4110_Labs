#revision number: 1
#begin 3/20/2022

#Issue 1
#program will:
#               Compute the volume of a sphere with a radius of 5. The formula for a sphere is 4⁄3πr3. 
#               Note: The answer is around 500
def print_volume():
    #get radius
    r = float(input("Enter sphere radius: "))

    #function to get volume
    def shere_volume(r):
        PI = 3.1415926
        #calculate volume
        volume = (4 / 3) * PI * r * r * r
        return volume

    volume = shere_volume(r)
    #print volume
    print("Volume of sphere with radius {} is {:.2f}".format(r,volume))


#Issue 2
#program will:
#               Write a recursive function print_range that prints the range of numbers from start to end,
#               where start and end are integer parameters to the function. 
#               Your code should work whether start is larger or smaller than end. 
def print_range(start,end):
    #print first value
    print(start)
    #for start = end
    if start == end:
        return 
    #for start > end 
    elif start>end:
        print_range(start-1, end)
    #for start < end 
    else:
        print_range(start+1, end)


#Issue 3
#program will:
#               Write a recursive function called gcd that takes parameters a and b 
#               and returns their greatest common divisor. You can assume that both a and b are positive integers.
#               Make sure your code is written such that gcd(a, b) == gcd(b, a).
def gcd(a,b):
    #cases a or b is 0
    if (a==0):
        return b
    if (b==0):
        return a

    #case a=b
    if (a==b):
        return a

    #case for a>b
    if (a>b):
        return gcd(a-b,b)
    #case a<b
    else:
        return gcd(a,b-a)


#Issue 4
#program will:
#               1.	Creates an empty list called "sales_data"
#               2.	Opens up the provided file SalesJan2009.csv (you need to download it to your hard drive) 
#                   and converts the data within it to JSON format.  The fields in the file are listed in order as follows:
#                   -Transaction_date
#                   -Product
#                   -Price
#                   -Payment_Type
#                   -Name
#                   -City
#                   -State
#                   -Country
#               3.	You will process this line-by-line and create a dictionary of each line. As you create each dictionary,
#                    you will append it to the sales_data list. You must also clean up extra quote characters from each piece of data you process.
#               4.	At the end of your processing, you will save your sales_data list to a file called "transaction_data.json"
import json
import csv
import pickle
def csv_json():

    #create list
    sales_data = []

    #open csv file for reading
    data = open('SalesJan2009.csv')

    #row counter
    rowCount = 0

    #copy csv file to sales_data(with dictionarys)
    for row in data:

        #row counter
        rowCount = 0

        # remove quotations and split the columns 
        removeQot = row.replace('"',"")
        split = removeQot.split(",")

        #create a new dictionary in the list
        sales_data.append({})

        #fill sales_data
        sales_data[rowCount]["TransactionDate"] = split[0] 
        sales_data[rowCount]["Product"] = split[1]
        sales_data[rowCount]["Price"] = split[2]
        sales_data[rowCount]["PaymentType"] = split[3]
        sales_data[rowCount]["Name"] = split[4]
        sales_data[rowCount]["City"] = split[5]
        sales_data[rowCount]["State"] = split[6]
        sales_data[rowCount]["Country"] = split[7]

        rowCount += 1 

    #write sales_data to the json file
    with open('transaction_data.json', 'w') as f:
        json.dump(sales_data, f)

    #interaction to show that the function is complete
    print("csv copied to json")
    




def main():
    #Issue 1
    print_volume()

    #Issue 2
    print_range(1,10)
    print_range(10,1)
    print_range(5,5)

    #Issue 3
    print(gcd(32,14))
    print(gcd(68,15))
    print(gcd(17,17))
    print(gcd(0,8))

    #Issue 4
    csv_json()


if __name__ == "__main__":
    main()
#Revision number: 3
#end 3/24/2022
# Group / manager/ lead tech/ project 
# HALF-LIFE/ Ron Bass/ John Richards Sr./ After-Burner Elite
